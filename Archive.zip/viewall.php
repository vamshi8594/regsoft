<html>
<style>
#fieldset ul {
	list-style: none;
	margin: 0 auto;
	padding: 0; }
#fieldset li {
	float:center;
padding-right:30px;	}
iframe {
        border:none;
}
table.tab{
position:fixed;
left:100px;
}
a.menu
{
display: block;
    width: 120px;
    font-weight: bold;
    color: black;
    background-color: #dddddd;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}
a.current,a:hover
{
    display: block;
    width: 120px;
    font-weight: bold;
    color: lightblue;
    background-color: black;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}
</style>
<iframe id="frames" src="edit.php"  width="920px" height="940px" style="float:left; position: relative; left:300px;" " >
</iframe>
</html>