<html>
<style>
iframe {
border:none;
}

</style>
<iframe id="frames" src="eventview.php" class="frameleft" width="600px" height="360px" style="float:right; position: relative; left:-90px;">

</iframe>
<iframe id="frames" src="register_iframe.html" class="frameleft" width="512px" height="360px" style="float:right; position: relative; left:-100px;" >
</iframe>
</html>